# dreamimage
View Images in a COOL way. A JQUERY library.

## To use the library
``` $(element).dreamimage();```

_Note: Here the element must be an img tag._
